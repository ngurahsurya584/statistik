<?php



namespace App\Controllers;

use App\Controllers\BaseController;
use PharIo\Manifest\Library;
use PHPUnit\TextUI\XmlConfiguration\Loader;
use \PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


class OpenController extends BaseController
{
	protected $mahasiswaModel;
	public function __construct()
	{
		$this->mahasiswaModel = new \App\Models\MahasiswaModel();
		helper('form');
	}

	public function export()
	{
		$dataNilai = $this->mahasiswaModel->findAll();

		$spreadsheet = new Spreadsheet();
		// tulis header/nama kolom 
		$spreadsheet->setActiveSheetIndex(0)
			->setCellValue('A1', 'Nilai');

		$column = 2;
		// tulis data mobil ke cell
		foreach ($dataNilai as $data) {
			$spreadsheet->setActiveSheetIndex(0)
				->setCellValue('A' . $column, $data['nilai']);
			$column++;
		}
		// tulis dalam format .xlsx
		$writer = new Xlsx($spreadsheet);
		$fileName = 'Data Nilai';

		// Redirect hasil generate xlsx ke web client
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename=' . $fileName . '.xlsx');
		header('Cache-Control: max-age=0');

		$writer->save('php://output');




		// $data = [
		// 	'nilai' => $this->mahasiswaModel->getMahasiswa(),
		// ];

		// return view('/Statistik/excel', $data);
	}

	public function export1()
	{
		$data = [
			'nilai' => $this->mahasiswaModel->getMahasiswa(),
		];

		return view('/Statistik/excel', $data);
	}

	public function uploaddata()
	{
		$file = $this->request->getFile('importexcel');
		// dd($file);
		$ext = $file->guessextension();
		// $oriFile = 'C:\xampp\tmp\\'. '' . $file->getClientName();
		// dd($oriFile);


		if ($ext == 'xlsx') {
			$reader = new \PhpOffice\PhpSpreadsheet\Reader\xlsx();
		} else {
			$reader = new \PhpOffice\PhpSpreadsheet\Reader\xls();
		}
		$spreadsheet = $reader->load($file);

		$sheet = $spreadsheet->getActiveSheet()->toArray();

		foreach ($sheet as $x => $excel) {
			//skip judul tabel
			if ($x == 0) {
				continue;
			}

			$data = [
				'nilai' => $excel['0'],
			];

			$this->mahasiswaModel->add($data);
		}

		session()->setFlashData('pesan6', 'Selamat, Data Berhasil Diimport.');
		return redirect()->to('/OpenController');
	}



	public function index()
	{
		$db = \Config\Database::connect(); {
			$builder = $db->table('mahasiswa');

			$builder->selectMax('nilai');
			$query = $builder->get();

			$builder->selectMin('nilai');
			$nMin = $builder->get();

			$builder->selectAvg('nilai');
			$nAvg = $builder->get();

			$builder->selectCount('nilai');
			$nTotal = $builder->get();

			$builder->selectSum('nilai');
			$nSum = $builder->get();

			$nf = $db->query('SELECT nilai, COUNT(*) as count FROM mahasiswa GROUP BY nilai');
		}


		$data = [
			'nf' => $nf,
			'nSum' => $nSum,
			'nTotal' => $nTotal,
			'nAvg' => $nAvg,
			'nMin' => $nMin,
			'nMax' => $query,
			'title' => 'Statistik Deskriptif | Statistik',
			'mahasiswa' => $this->mahasiswaModel->getMahasiswa()
		];

		return view('Statistik/opening_message', $data);
	}

	public function edit($id)
	{

		$data =
			[
				'title' => 'edit data',
				'mahasiswa' => $this->mahasiswaModel->getMahasiswa($id),
				'validation' => \config\Services::validation()

			];

		return view('statistik/edit', $data);
	}

	public function save()
	{

		if (!$this->validate([
			'nilai' => 'required'
		])) {
			session()->setFlashData('pesan2', 'Maaf, Data Gagal Ditambah Jika Nilai Tidak Terisi');
			return redirect()->to('/OpenController');
		}

		$request = service('request');
		$request->getVar();
		$this->mahasiswaModel->save([
			'nilai' => $request->getVar('nilai')
		]);

		session()->setFlashData('pesan1', 'Selamat, Data Berhasil Ditambahkan.');

		return redirect()->to('/OpenController');
	}

	public function delete($id)
	{
		$this->mahasiswaModel->delete($id);
		session()->setFlashData('pesan3', 'Selamat, Data Berhasil Dihapus.');
		return redirect()->to('/OpenController');
	}

	public function update($id)
	{

		$request = service('request');
		$request->getVar();
		$id = url_title($request->getVar('id'), true);
		$this->mahasiswaModel->save([
			'id' => $id,
			'nilai' => $request->getVar('nilai')
		]);

		session()->setFlashData('pesan4', 'Selamat, Data Berhasil Dirubah.');

		return redirect()->to('/OpenController');
	}
}